# ReadStep Offline App

This package prepares the existing ReadStep HTML project as an installable Progressive Web App (PWA).

## Files
- `index.html` — original reading activity, with PWA links and service-worker registration added
- `manifest.json` — app name, install behavior, and icons
- `service-worker.js` — caches the app shell and online resources for offline use
- `icons/` — app icons

## Publish for students
1. Upload all files and the `icons` folder to the ROOT of your existing GitHub repository (the same folder as `index.html`).
2. In GitHub, open Settings → Pages. Select branch `main` and folder `/(root)`, then save.
3. Wait for deployment and open the HTTPS GitHub Pages address on a laptop or Android phone while online.
4. Keep the app open online until the page has loaded and the service worker has installed. Open the activities and let them load at least once.
5. Install it from the browser's Install app option (laptop) or Install app / Add to Home screen (Android).
6. Turn off internet and reopen the installed app to test.

## Important offline notes
- Each student's device needs to open the hosted app online at least once to cache it before offline use.
- The service worker requires HTTPS (GitHub Pages provides HTTPS) or localhost; it will not work by opening `index.html` directly from a file manager.
- The original HTML loads Tailwind CSS, Font Awesome, Google Fonts, PptxGenJS, and Canvas Confetti from CDNs. The service worker tries to cache these during setup and caches further same-origin/cross-origin GET resources as they load. If a CDN is blocked or unavailable during first setup, some visual effects, fonts, or PowerPoint export may not work offline.
- This package does not upload or publish itself to GitHub. The owner must upload these files to the repository.
