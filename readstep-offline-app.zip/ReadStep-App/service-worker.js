const CACHE_NAME = "readstep-offline-v1";

const APP_FILES = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

// Libraries used by the existing ReadStep HTML.
// They are cached during the first online setup when available.
const EXTERNAL_FILES = [
  "https://cdn.tailwindcss.com",
  "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
  "https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Quicksand:wght@500;600;700&display=swap",
  "https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js",
  "https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(APP_FILES);

    // Cache each external library independently so one unavailable CDN
    // does not prevent the app shell from being installed.
    await Promise.all(EXTERNAL_FILES.map(async (url) => {
      try {
        const response = await fetch(url, { mode: "no-cors", cache: "reload" });
        if (response && (response.ok || response.type === "opaque")) {
          await cache.put(url, response);
        }
      } catch (error) {
        console.warn("Could not cache optional online resource:", url);
      }
    }));
  })());

  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys
      .filter((key) => key.startsWith("readstep-offline-") && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;

  event.respondWith((async () => {
    const cached = await caches.match(event.request, { ignoreVary: true });
    if (cached) return cached;

    try {
      const response = await fetch(event.request);

      // Cache successful same-origin files and cross-origin assets that
      // can be stored by the browser. Ignore caching errors gracefully.
      if (response && (response.ok || response.type === "opaque")) {
        const cache = await caches.open(CACHE_NAME);
        try {
          await cache.put(event.request, response.clone());
        } catch (error) {
          // Some browser responses cannot be cached; the page can still use them online.
        }
      }
      return response;
    } catch (error) {
      // For an offline navigation, show the cached app shell.
      if (event.request.mode === "navigate") {
        const appPage = await caches.match("./index.html");
        if (appPage) return appPage;
      }

      return new Response(
        "This resource is not available offline yet. Connect to the internet once, reopen ReadStep, and try again.",
        { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } }
      );
    }
  })());
});
